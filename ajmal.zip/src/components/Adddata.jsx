import { Button, Typography } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'

const Adddata = () => {
  return (
    <div  style={{paddingTop:"80px"}}>
    <Typography>
    <Button variant='Info' color='success'><Link to={'/'} style={{textDecoration:'none'}}>Return</Link></Button>
    </Typography></div>
  )
}

export default Adddata